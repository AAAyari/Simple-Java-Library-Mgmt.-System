package packLibrary;

public interface Person {
    void displayDetails(); // maktebtech public khater public par defaut
}
