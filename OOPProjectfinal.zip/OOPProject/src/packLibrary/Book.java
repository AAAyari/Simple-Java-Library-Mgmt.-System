package packLibrary;

public class Book extends Medium {
    private String genre;
    private boolean isAvailable;

    public Book(int id, String title, String author, int publicationYear, String genre) {
        super(id, title, author, publicationYear);
        this.genre = genre;
        this.isAvailable = true;
    }

    @Override
    public boolean isAvailable() {
        return isAvailable;
    }

    public void setAvailable(boolean available) {isAvailable = available;}

    @Override
    public void displayDetails() {
        super.displayDetails();
        System.out.println("Genre: " + genre);
        System.out.println("Available: " + (isAvailable ? "Yes" : "No"));
    }
}
