package packLibrary;

public class Member implements Person{
    private int memberId;
    private String name;
    private int[] borrowedBooks;
    private int borrowedCount;

    private static final int MAX_BORROWED_BOOKS = 5; //Max borrowable books

    public Member(int memberId, String name) {  // C
        this.memberId = memberId;
        this.name = name;
        this.borrowedBooks = new int[MAX_BORROWED_BOOKS];
        this.borrowedCount = 0;
    }

    public int getMemberId() {return memberId;}
    public String getName() {return name;}
    public int[] getBorrowedBooks() {return borrowedBooks;}
    public int getBorrowedCount() {return borrowedCount;}

    // Add book to member's list (called in class Library)
    public boolean addBookToList(int bookId) {
        if (borrowedCount < MAX_BORROWED_BOOKS) {
            borrowedBooks[borrowedCount] = bookId;
            borrowedCount++;
            return true;
        }
        return false;
    }

    // Same thing
    public boolean removeBookFromList(int bookId) {
        for (int i = 0; i < borrowedCount; i++) {
            if (borrowedBooks[i] == bookId) {
                // Shift elements to the left, fill the gap created by the removal function
                for (int j = i; j < borrowedCount - 1; j++) {
                    borrowedBooks[j] = borrowedBooks[j + 1];
                }
                borrowedBooks[borrowedCount - 1] = 0; // Clear last element
                borrowedCount--;
                return true;
            }
        }
        return false;
    }

    @Override
    public void displayDetails() {
        System.out.println("\nMember ID: " + memberId);
        System.out.println("Name: " + name);
        System.out.print("Borrowed Books: ");
        if (borrowedCount == 0) {
            System.out.println("None");
        } else {
            for (int i = 0; i < borrowedCount; i++) {
                System.out.print(borrowedBooks[i]);
                if (i < borrowedCount - 1) {
                    System.out.print(", "); // Add a comma after each book ID except the last one
                }
            }
        }
    }
}
