package packLibrary;

public class Library {

    private static final int MAX_BOOKS = 1000; // Max books
    private static final int MAX_MEMBERS = 500; // Max members

    private Book[] books;
    private Member[] members;
    private int bookCount;
    private int memberCount;

    public Library() {
        books = new Book[MAX_BOOKS];
        members = new Member[MAX_MEMBERS];
        bookCount = 0;
        memberCount = 0;
    }

    // Add new book to library
    public boolean addBook(Book book) {
        if (bookCount < MAX_BOOKS) {
            books[bookCount] = book;
            bookCount++;
            System.out.println("Book added successfully!");
            return true;
        } else {
            System.out.println("Error: Library's book capacity is full.");
            return false;
        }
    }

    // Delete book from library
    public boolean deleteBook(int bookId) {
        for (int i = 0; i < bookCount; i++) {
            if (books[i].getId() == bookId) {
                // Shift books to the left to fill the gap
                for (int j = i; j < bookCount - 1; j++) {
                    books[j] = books[j + 1];
                }
                books[bookCount-1] = null;
                bookCount--;
                System.out.println("Book deleted successfully!");
                return true;
            }
        }
        System.out.println("Error: Book not found.");
        return false;
    }

    // Add member to library
    public boolean addMember(Member member) {
        if (memberCount < MAX_MEMBERS) {
            members[memberCount] = member;
            memberCount++;
            System.out.println("Member added successfully!");
            return true;
        } else {
            System.out.println("Error: Library's member capacity is full'.");
            return false;
        }
    }

    // Delete member from library
    public boolean deleteMember(int memberId) {
        for (int i = 0; i < memberCount; i++) {
            if (members[i].getMemberId() == memberId) {
                // Shift elements to the left and fill the gap created by the removal
                for (int j = i; j < memberCount - 1; j++) {
                    members[j] = members[j + 1];
                }
                members[memberCount-1] = null;
                memberCount--;
                System.out.println("Member deleted successfully!");
                return true;
            }
        }
        System.out.println("Error: Member not found.");
        return false;
    }

    // Search book using ID
    public Book searchBook(int bookId) {
        for (int i = 0; i < bookCount; i++) {
            if (books[i].getId() == bookId) {
                return books[i];
            }
        }
        return null; // Book not found
    }

    public Book searchBookByTitle(String title) {
        for (int i = 0; i < bookCount; i++) {  // Use bookCount to iterate only actual books
            if (books[i].getTitle().equalsIgnoreCase(title)) {
                return books[i];  // Return book
            }
        }
        return null;  // Return null if title not found
    }

    // List books
    public void listBooks() {
        if (bookCount == 0) {
            System.out.println("No books in the library.");
            return;
        }
        for (int i = 0; i < bookCount; i++) {
            books[i].displayDetails();
        }
    }

    // List members
    public void listMembers() {
        if (memberCount == 0) {
            System.out.println("No members in the library.");
            return;
        }
        for (int i = 0; i < memberCount; i++) {
            members[i].displayDetails();
        }
    }

    // Borrow book
    public boolean borrowBook(int bookId, int memberId) {
        Book book = searchBook(bookId);
        if (book == null || !book.isAvailable()) {
            System.out.println("Error: Book is not available.");
            return false;
        }

        for (int i = 0; i < memberCount; i++) {
            if (members[i].getMemberId() == memberId) {
                if (members[i].addBookToList(bookId)) { // Using borrowedCount
                    book.setAvailable(false); // Mark book as borrowed
                    return true;
                } else {
                    System.out.println("Error: Member cannot borrow more books.");
                    return false;
                }
            }
        }
        System.out.println("Error: Member not found.");
        return false;
    }

    // Return book
    public boolean returnBook(int bookId, int memberId) {
        Book book = searchBook(bookId);
        if (book == null) {
            System.out.println("Error: Book not found.");
            return false;
        }

        for (int i = 0; i < memberCount; i++) {
            if (members[i].getMemberId() == memberId) {
                if (members[i].removeBookFromList(bookId)) {
                    book.setAvailable(true); // Mark book as available
                    return true;
                } else {
                    System.out.println("Error: Book not found in member's borrowed list.");
                    return false;
                }
            }
        }
        System.out.println("Error: Member not found.");
        return false;
    }
}

