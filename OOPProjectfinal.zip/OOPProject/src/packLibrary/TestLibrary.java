package packLibrary;
import java.util.Scanner;

public class TestLibrary {
    public static void main(String[] args) {
        Library library = new Library();
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("\nLibrary Management System");
            System.out.println("1. Add Book");
            System.out.println("2. Add Member");
            System.out.println("3. Borrow Book");
            System.out.println("4. Return Book");
            System.out.println("5. List Books");
            System.out.println("6. List Members");
            System.out.println("7. Search book by title");
            System.out.println("8. Delete member");
            System.out.println("9. Exit");
            System.out.print("Enter your choice: ");
            int choice = sc.nextInt();

            switch (choice) {
                case 1: // Add book
                    System.out.print("Enter Book ID: ");
                    int bookId = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Enter Title: ");
                    String title = sc.nextLine();
                    System.out.print("Enter Author: ");
                    String author = sc.nextLine();
                    System.out.print("Enter Genre: ");
                    String genre = sc.nextLine();
                    System.out.print("Enter Publication Year: ");
                    int year = sc.nextInt();

                    Book book = new Book(bookId, title, author, year, genre);
                    library.addBook(book);
                    break;

                case 2: // Add member
                    System.out.print("Enter Member ID: ");
                    int memberId = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Enter Name: ");
                    String name = sc.nextLine();

                    Member member = new Member(memberId, name);
                    library.addMember(member);
                    break;

                case 3: // Borrow book
                    System.out.print("Enter Book ID to borrow: ");
                    int borrowBookId = sc.nextInt();
                    System.out.print("Enter Member ID: ");
                    int borrowerId = sc.nextInt();

                    if (library.borrowBook(borrowBookId, borrowerId)) {
                        System.out.println("Book borrowed successfully!");
                    } else {
                        System.out.println("Failed to borrow book. Please check availability or member details.");
                    }
                    break;

                case 4: // Return book
                    System.out.print("Enter Book ID to return: ");
                    int returnBookId = sc.nextInt();
                    System.out.print("Enter Member ID: ");
                    int returnerId = sc.nextInt();

                    if (library.returnBook(returnBookId, returnerId)) {
                        System.out.println("Book returned successfully!");
                    } else {
                        System.out.println("Failed to return book. Please check member details or book ID.");
                    }
                    break;

                case 5: // List books
                    System.out.println("\nList of Books:");
                    library.listBooks();
                    break;

                case 6: // List members
                    System.out.println("\nList of Members:");
                    library.listMembers();
                    break;

                case 7: // Search Book by Title
                    System.out.print("Enter Book Title to search: ");
                    sc.nextLine(); // Consume newline
                    String searchTitle = sc.nextLine();
                    Book foundBook = library.searchBookByTitle(searchTitle);
                    if (foundBook != null) {
                        foundBook.displayDetails();
                    } else {
                        System.out.println("No book found with the title: " + searchTitle);
                    }
                    break;

                case 8: // Delete member
                    System.out.print("Enter Member ID to delete: ");
                    int deleteMemberId = sc.nextInt();
                    library.deleteMember(deleteMemberId);
                    break;


                case 9: // Exit
                    System.out.println("Exiting... Goodbye!");
                    sc.close();
                    return;

                default: // Invalid Choice
                    System.out.println("Invalid choice. Please try again!");
                    break;
            }
        }
    }
}


