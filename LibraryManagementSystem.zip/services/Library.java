package services;

import models.Book;
import models.Member;

import java.util.ArrayList;

public class Library {
    private ArrayList<Book> books;
    private ArrayList<Member> members;

    public Library() {
        books = new ArrayList<>();
        members = new ArrayList<>();
    }

    public void addBook(Book book) {
        books.add(book);
        System.out.println("Book added successfully!");
    }

    public void deleteBook(int bookId) {
        books.removeIf(book -> book.getBookId() == bookId);
        System.out.println("Book deleted successfully!");
    }

    public void addMember(Member member) {
        members.add(member);
        System.out.println("Member added successfully!");
    }

    public void deleteMember(int memberId) {
        members.removeIf(member -> member.getMemberId() == memberId);
        System.out.println("Member deleted successfully!");
    }

    public Book searchBook(int bookId) {
        for (Book book : books) {
            if (book.getBookId() == bookId) {
                return book;
            }
        }
        return null;
    }

    public void listBooks() {
        for (Book book : books) {
            book.displayDetails();
        }
    }

    public void listMembers() {
        for (Member member : members) {
            member.displayDetails();
        }
    }
}
